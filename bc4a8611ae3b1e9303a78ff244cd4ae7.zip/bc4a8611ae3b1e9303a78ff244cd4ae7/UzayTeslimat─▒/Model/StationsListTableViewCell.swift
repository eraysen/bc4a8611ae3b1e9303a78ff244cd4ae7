//
//  StationsListTableViewCell.swift
//  UzayTeslimatı
//
//  Created by Eray Sen on 17.08.2021.
//

import UIKit

class StationsListTableViewCell: UITableViewCell {

    @IBOutlet weak var stationNameLabel: UILabel!
    
    @IBOutlet weak var capacityStockLabel: UILabel!
    @IBOutlet weak var eusLabel: UILabel!
    @IBOutlet weak var favoriteImageView: UIImageView! {
        didSet {
            favoriteImageView.image = UIImage(systemName: "star")
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
