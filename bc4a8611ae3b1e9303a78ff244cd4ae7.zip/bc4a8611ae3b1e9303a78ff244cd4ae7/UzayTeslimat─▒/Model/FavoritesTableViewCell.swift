//
//  FavoritesTableViewCell.swift
//  UzayTeslimatı
//
//  Created by Eray Sen on 16.08.2021.
//

import UIKit

class FavoritesTableViewCell: UITableViewCell {

    @IBOutlet weak var spaceStationNameLabel: UILabel!
    @IBOutlet weak var eusLabel: UILabel!
    @IBOutlet weak var isFavoriteImage: UIImageView!{
        didSet {
            isFavoriteImage.image = UIImage(systemName: "star.fill")
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
