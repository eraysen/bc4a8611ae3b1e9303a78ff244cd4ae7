//
//  StationsModel.swift
//  UzayTeslimatı
//
//  Created by Eray Sen on 16.08.2021.
//

import Foundation

