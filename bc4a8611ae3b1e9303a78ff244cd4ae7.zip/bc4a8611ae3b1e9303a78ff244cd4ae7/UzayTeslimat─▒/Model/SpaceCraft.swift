//
//  SpaceCraft.swift
//  UzayTeslimatı
//
//  Created by Eray Sen on 14.08.2021.
//

import Foundation

struct SpaceCraft {
    
    var damageCapacity = 100
    var speed: Int?
    var materialCapacity: Int?
    var resistance: Int?
}
