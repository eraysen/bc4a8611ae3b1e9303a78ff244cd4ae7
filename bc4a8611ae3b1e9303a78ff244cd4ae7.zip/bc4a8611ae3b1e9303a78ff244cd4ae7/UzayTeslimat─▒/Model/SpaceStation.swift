//
//  SpaceStation.swift
//  UzayTeslimatı
//
//  Created by Eray Sen on 14.08.2021.
//

import Foundation
import CoreLocation

struct SpaceStation {
    let capacity: Int?
    let coordinates: CLLocationCoordinate2D?
}
