//
//  StringConstants.swift
//  UzayTeslimatı
//
//  Created by Eray Sen on 15.08.2021.
//

import Foundation

public struct Strings {
    public static let favorites = "Favoriler"
}
