//
//  FavoritesViewController.swift
//  UzayTeslimatı
//
//  Created by Eray Sen on 15.08.2021.
//

import UIKit

class FavoritesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var favoritesTableView: UITableView! {
        didSet {
            favoritesTableView.delegate = self
            favoritesTableView.dataSource = self
        }
    }
    var favoritesTableViewCell = "FavoritesTableViewCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.visibleViewController?.title = Strings.favorites
        favoritesTableView.rowHeight = 100
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: favoritesTableViewCell) as! FavoritesTableViewCell
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: nil)
        cell.isFavoriteImage.isUserInteractionEnabled = true
        cell.isFavoriteImage.addGestureRecognizer(tapGestureRecognizer)
        return cell
    }

}
