//
//  StationsViewController.swift
//  UzayTeslimatı
//
//  Created by Eray Sen on 15.08.2021.
//

import UIKit
import Alamofire

class StationsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var stationsListTableView: UITableView! {
        didSet {
            stationsListTableView.delegate = self
            stationsListTableView.dataSource = self
        }
    }
    var damageCapacity = 100
    var ugs: Int?
    var eus: Int?
    var ds: Int?
    @IBOutlet weak var ugsLabel: UILabel!
    @IBOutlet weak var eusLabel: UILabel!
    @IBOutlet weak var dsLabel: UILabel!
    @IBOutlet weak var spaceCraftNameLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var damageCapacityLabel: UILabel! {
        didSet {
            damageCapacityLabel.text = String("\(damageCapacity)")
        }
    }
    var stationArray = NSMutableArray()
    var stationsListTableViewCell = "StationsListTableViewCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getStationsListApi()
        spaceCraftNameLabel.text = UserDefaults.standard.value(forKey: "spaceCraftName") as? String
        if let capacity = UserDefaults.standard.value(forKey: "capacitySliderValue") {
            ugs = capacity as! Int * 10000
            ugsLabel.text = "UGS: \(ugs ?? 1)"
        }
        if let speed = UserDefaults.standard.value(forKey: "speedSliderValue") {
            eus = speed as! Int * 20
            eusLabel.text = "EUS: \(eus ?? 1)"
        }
        if let resistance = UserDefaults.standard.value(forKey: "resistanceSliderValue") {
            ds = resistance as! Int * 10000
            dsLabel.text = "DS: \(ds ?? 1)"
        }
        stationsListTableView.rowHeight = 150
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.stationArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: stationsListTableViewCell) as! StationsListTableViewCell
        let asset = self.stationArray[indexPath.row] as! [String: Any]
//        cell.stationNameLabel.text =  asset["name"] as! String
        cell.stationNameLabel.text = "name"
        
        
    
        
        return cell
    }
    
    func getStationsListApi() {
        let url = "https://run.mocky.io/v3/e7211664-cbb6-4357-9c9d-f12bf8bab2e2"
        
        AF.request(url, method: .post, parameters: nil, encoding: URLEncoding.default, headers: nil).validate(contentType: ["application/json"]).responseJSON { (response) in
            do {
                let statusCode = response.response?.statusCode
                if statusCode! >= 200 {
                    if let jsonResult = try JSONSerialization.jsonObject(with: response.data!, options: []) as? NSDictionary {
                        if let status = jsonResult.object(forKey: "status") as? String, status == "OK" {
                            let data = jsonResult.object(forKey: "data") as! NSDictionary
                            print(data)
                            if (data.count) > 0 {
                                for item  in data {
                                    self.stationArray.add(item.value)
                                }
                            }
                        }
                    }
                }
            } catch {
                
            }
        }
    }
}
