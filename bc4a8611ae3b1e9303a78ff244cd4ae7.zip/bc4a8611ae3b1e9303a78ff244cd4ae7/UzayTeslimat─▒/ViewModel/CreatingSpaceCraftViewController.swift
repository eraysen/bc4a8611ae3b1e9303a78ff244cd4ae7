//
//  ViewController.swift
//  UzayTeslimatı
//
//  Created by Eray Sen on 14.08.2021.
//

import UIKit
import CoreData

class CreatingSpaceCraftViewController: UIViewController {

    @IBOutlet weak var spaceCraftName: UITextField!
    @IBOutlet weak var spaceCraftTotalPointsLabel: UILabel!
    @IBOutlet weak var resistanceSlider: UISlider!
    @IBOutlet weak var resistanceLabel: UILabel!
    @IBOutlet weak var speedSlider: UISlider!
    @IBOutlet weak var speedLabel: UILabel!
    @IBOutlet weak var capacitySlider: UISlider!
    @IBOutlet weak var capacityLabel: UILabel!
    @IBOutlet weak var continueButton: UIButton! {
        didSet {
            continueButton.layer.borderWidth = 2
        }
    }
    
    var resistanceSliderValue = 1
    var speedSliderValue = 1
    var capacitySliderValue = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func continueButton(_ sender: Any) {
        UserDefaults.standard.set(spaceCraftName.text, forKey: "spaceCraftName")
        UserDefaults.standard.set(spaceCraftTotalPointsLabel.text, forKey: "spaceCraftTotalPoints")
        UserDefaults.standard.set(resistanceSliderValue, forKey: "resistanceSliderValue")
        UserDefaults.standard.set(speedSliderValue, forKey: "speedSliderValue")
        UserDefaults.standard.set(capacitySliderValue, forKey: "capacitySliderValue")
    }
    
    @IBAction func resistanceSliderChanged(_ sender: UISlider) {
        resistanceLabel.text = "Dayanıklılık: \(resistanceSlider.value)"
        sender.setValue(Float(lroundf(resistanceSlider.value)), animated: true)
        self.resistanceSliderValue = Int(resistanceSlider.value)
        let totalPoints = self.resistanceSliderValue + self.speedSliderValue + self.capacitySliderValue
        spaceCraftTotalPointsLabel.text = "\(totalPoints)"
    }
    
    @IBAction func speedSliderChanged(_ sender: UISlider) {
        speedLabel.text = "Hız: \(speedSlider.value)"
        sender.setValue(Float(lroundf(speedSlider.value)), animated: true)
        self.speedSliderValue = Int(speedSlider.value)
        let totalPoints = self.resistanceSliderValue + self.speedSliderValue + self.capacitySliderValue
        spaceCraftTotalPointsLabel.text = "\(totalPoints)"
    }
    
    @IBAction func capacitySliderChanged(_ sender: UISlider) {
        capacityLabel.text = "Kapasite: \(capacitySlider.value)"
        sender.setValue(Float(lroundf(capacitySlider.value)), animated: true)
        self.capacitySliderValue = Int(capacitySlider.value)
        let totalPoints = self.resistanceSliderValue + self.speedSliderValue + self.capacitySliderValue
        spaceCraftTotalPointsLabel.text = "\(totalPoints)"
    }
    
}

